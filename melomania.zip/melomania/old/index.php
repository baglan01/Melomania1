<?php
    //  вся процедура работает на сессиях. Именно в ней хранятся данные  пользователя, пока он находится на сайте. Очень важно запустить их в  самом начале странички!!!
    session_start();
    ?>
<?php
include("phptest.php");
?>

<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Melomania - share, comment, create!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Styles and JS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--Scripts -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 




     <!-- CSS -->
    <style type="text/css">
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   color: white;
   background-color:gray;
   text-align: center;
}

 .navbar-inverse {
 
  background-color: #000000;
 
  border-color: #551BFA;
 
}
.navbar-default .navbar-text {
 
  color: #551BFA;
 
}

.active{
background-color: #424949;


}

.nav-item {
    margin-right: 20px;
}

.form.inline{

	    margin-right: 20px;

}
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }

  .carousel {

  width: 100%;
  height:100%;
  align-content: center;

}

 .carousel-item{
   height:200px;
 }
section {
    padding: 60px 0;
}

section .section-title {
    text-align: center;
    color: #222;
    margin-bottom: 50px;
    text-transform: uppercase;
}
#footer {
    background: #222 !important;
}
#footer h5{
  padding-left: 10px;
    border-left: 3px solid #eeeeee;
    padding-bottom: 6px;
    margin-bottom: 20px;
    color:#080808;
}
#footer a {
    color: #ffffff;
    text-decoration: none !important;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
#footer ul.social li{
  padding: 3px 0;
}
#footer ul.social li a i {
    margin-right: 5px;
  font-size:25px;
  -webkit-transition: .5s all ease;
  -moz-transition: .5s all ease;
  transition: .5s all ease;
}
#footer ul.social li:hover a i {
  font-size:30px;
  margin-top:-10px;
}
#footer ul.social li a,
#footer ul.quick-links li a{
  color:#ffffff;
}
#footer ul.social li a:hover{
  color:#eeeeee;
}

@media (max-width:767px){
  #footer h5 {
    padding-left: 0;
    border-left: transparent;
    padding-bottom: 0px;
    margin-bottom: 10px;
}
}




</style>
     <!-- Icon -->

<link rel="shortcut icon" href="logo-final-dark-sized.png">

</head>


<body>
     <!-- Navigation panel -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="\index.php"> Melomania</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
     <!-- Nav:home -->

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="\index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
     <!-- Nav:home -->

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Store</a>
     <!-- Nav:store/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Customization</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Playlists</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-danger btn-sm btn-block" role="button" aria-disabled="true">Notes and Keys</a>
          <div class="dropdown-divider"></div>

        </div>
      </li>

     <!-- Nav:playlist -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Playlists</a>
     <!-- Nav:playlist/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Rock playlist</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Jazz playlist</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Hiphop playlist</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Rap playlist</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Special playlist</a>
        </div>



     <!-- Nav:community -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Community</a> 
     <!-- Nav:community/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="/forum/" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Forum</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Teams, Clans</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Events</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">TOP 100</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">F.A.Q.</a>
        </div>

     <!-- Nav:myprofile -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

     <!-- PHP user getName() -->
          <?php

          if(empty($_SESSION['login'])) {

             echo "My profile";

          }
          
          else{

          echo "".$_SESSION['login']."";
          
          }

          ?>


        </a>  

     <!-- Nav:myprofile/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My statistics</a>
          <div class="dropdown-divider"></div>
          <a href="/profile.php?login=

<?php
//admin check

$adminquery = mysql_query("SELECT adminaccesss FROM users WHERE login='$login'", $db);

          echo "".$_SESSION['login']."";


?>
          "
          class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My profile</a>
           
         






        </div>
      </li>
    </ul>
     <!-- Nav:register or login -->

 <?php
if (empty($_SESSION['login'])) {
 
      echo'<a href="\register.php" class="btn btn-primary mb-2 mr-sm-2" role="button" aria-disabled="true">Register</a>';
      echo'<a href="\login.php" class="btn btn-success mb-2 mr-sm-2" role="button" aria-disabled="true">Login</a>';
      
    }

    else {
       echo'<a href="\logout.php" class="btn btn-success" role="button" aria-disabled="true">Logout</a>';

    }
 ?>


    
  <?php
   if (isset($_POST['logout'])) {

          unset($_SESSION['username']); 

  echo '<meta http-equiv="refresh" content="1; URL=/index.php">';

  session_destroy(); 
    } 

    ?>



    </form>


  </div>
</nav>	
     <!-- Carousel -->


<div id="carousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carousel" data-slide-to="0" class="active"></li>
        <li data-target="#carousel" data-slide-to="1"></li>
        <li data-target="#carousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="melo.png" alt="First slide">
            <div class="carousel-caption d-none d-md-block">
                <h5>Are you a master of jazz music?</h5>
                <p>Prove it and get x2 bonus to your XP</p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="melo.png" alt="Second slide">
                 <div class="carousel-caption d-none d-md-block">

                <h2>Weekly special event! Rock music classics</h2>
                <p></p>
               </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="melo.png" alt="Third slide">
                 <div class="carousel-caption d-none d-md-block">

                <h2>Welcome to</h2>
                <p></p>
               </div>


        </div>
    </div>
    <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

  <!-- Not registered -->

<?php
if(empty($_SESSION['login'])) {
   echo'<div class="alert alert-warning">';

   echo'<strong>You are not logged!</strong> To get full access to our site, register or login';
   echo'</div>';
 }
 else{

  echo'<div class="alert alert-primary">';
 
   echo '<strong>Welcome to Melomania, ';
   echo "".$_SESSION['login']."";

   echo'. </strong>';
   $random = rand(1, 7);
   if($random == 1){

   echo'Do not know where to start? You can warm up in "Single Player" mode';

}
   if($random == 2){

   echo'Do not forget that we also have a forum!';

}

   if($random == 3){

   echo'If you don’t know any songs, the "Playlists" tab will help you.';

}
   if($random == 4){

   echo'Do not know where to start? You can warm up in "Single Player" mode';

}
   if($random == 5){

   echo'Do not forget that we also have a forum!';

}

   if($random == 6){

   echo'If you don’t know any songs, the "Playlists" tab will help you.';

}

   if($random == 7){

   echo'Something mystical is hidden here...rlodthpg';

}
   echo'</div>';
 }
?>




<p> </p>
<p> </p>
<p> </p>
<p> </p>
<p> </p>

    <main role="main">

<div class="container">
        <!-- Main headings -->
        <div class="row">

          <div class="col-md-4">
            <img src="https://d.radikal.ru/d41/1912/79/82ec51575364.jpg" height="100" width="100">
            <h2>Special Events</h2>
            <p>Only this week - classic rock! (60-70-80 years). Hurry up!</p>
            <p><a class="btn btn-warning" href="#" role="button">I'm ready! »</a></p>
          </div>
                    <div class="col-md-4">
                    <img src="https://cdn4.iconfinder.com/data/icons/miscellaneous-icons-1/200/misc_game_multiplayer-512.png" height="100" width="100">
            <h2>Multiplayer</h2>
            <p>Want to know how much you are good at music? Then this is what you came for. Compete with other participants and find out who is the best in Melomania!</p>
            <p><a class="btn btn-success" href="#" role="button">Select genre »</a></p>
          </div>

                    <div class="col-md-4">
                      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGUlWqGoboPAPWsKoRNr80AA8E6I7zSzU-7y-nv4e56i4YuvlY&s
" height="100" width="100">
            <h2>Single player</h2>
            <p>The mode is intended for training. Want to train genres, you are here!</p>
            <p><a class="btn btn-success" href="#" role="button">Select genre »</a></p>
          </div>

                    <div class="col-md-4">
                      <img src="https://previews.123rf.com/images/vladwel/vladwel1712/vladwel171200001/90880520-versus-letters-or-vs-logo-vector-emblem-flat-cartoon-creative-logotype.jpg" height="100" width="100">
            <h2>VS Friend(beta)</h2>
            <p>Want to know who is best among friends? You here (Attention! This mode is in testing and may contain bugs. Please inform us about this)!</p>
            <p><a class="btn btn-success" href="#" role="button">Start! </a></p>
          </div>


          <div class="col-md-4">

            <img src="https://logodix.com/logo/1707081.png" height="100" width="100">
            <h2>Custom Mode</h2>
            <p>In developing</p>
            <p><a class="btn btn-danger" href="#" role="button">Currently not working</a></p>
          </div>



          <div class="col-md-4">
                        <img src="https://logodix.com/logo/1707081.png" height="100" width="100">

            <h2>Team VS Team</h2>
            <p>In developing</p>
            <p><a class="btn btn-danger" href="#" role="button">Currently not working</a></p>
          </div>

   <hr>
 </div> <!-- /container -->
    </main>


</body>




    

 <!-- Copyright -->
<!-- Footer -->
  <div class = "footer">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
          <ul class="list-unstyled list-inline social text-center">
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
          </ul>
        </div>
        </hr>
      </div>  
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
          <p><u><a href="https://www.nationaltransaction.com/">Melomania</a></u> is a registered trade mark</p>
          <p class="h6"><a class="text-green ml-2" href="https://www.sunlimetech.com" target="_blank">© Melomania Developers</a></p>
        </div>
        </hr>
      </div>  
      </div>
    </div>
  <!-- ./Footer -->

  <!-- Copyright -->

</html>