     <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>
</head>
<body onload="myFunction()" style="margin:0;">

<div id="loader"></div>

<div style="display:none;" id="myDiv" class="animate-bottom">

</div>

<script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

</body>
</html>


<?php


    if (isset($_POST['login'])) { $login = $_POST['login']; 
    if ($login == '') { unset($login);} } 
    if (isset($_POST['email'])) { $email = $_POST['email']; 
    if ($email == '') { unset($email);} }
    if (isset($_POST['password'])) { $password=$_POST['password']; 
    if ($password =='') { unset($password);} }
    
    if (isset($_POST['fname'])) { $fname = $_POST['fname'];
    if($fname == '') { unset($fname);} }

    if (isset($_POST['lname'])) { $lname = $_POST['lname'];
    if($lname == '') { unset($lname);} }

    if (isset($_POST['passwordconfirm'])) { $passwordconfirm=$_POST['passwordconfirm']; 
    if ($passwordconfirm =='') { unset($passwordconfirm);} }
   
   



  
 if (empty($login) or empty($password) or empty($lname) or empty($email) or  empty($passwordconfirm))  {

        echo '<meta http-equiv="refresh" content="3; URL=/register.php">';   
        echo '<script language="javascript">';
        echo 'alert("Error! You have not entered all the information")';
        echo '</script>';
        exit ("");



    }
    $login = stripslashes($login);
    $login = htmlspecialchars($login);
    $email = stripslashes($email);
    $email = htmlspecialchars($email);
    $password = stripslashes($password);
    $password = htmlspecialchars($password);
    $fname = stripslashes($fname);
    $fname = htmlspecialchars($fname);
    $lname = stripslashes($lname);
    $lname = htmlspecialchars($lname);
    
    $passwordconfirm = stripslashes($passwordconfirm);
    $passwordconfirm = htmlspecialchars($passwordconfirm);
   
    $login = trim($login);
    $email = trim($email);
    $password = trim($password);
    $passwordconfirm = trim($passwordconfirm);
    $fname = trim($fname);
    $lname = trim($lname);       



    if(strlen($password) < 6){
        echo '<meta http-equiv="refresh" content="3; URL=/register.php">';   
        echo '<script language="javascript">';
        echo 'alert("Error! Your passwords characters low than 6")';
        echo '</script>';
        exit ("");

    }



    if($password != $passwordconfirm){

        echo '<meta http-equiv="refresh" content="3; URL=/register.php">';   
        echo '<script language="javascript">';
        echo 'alert("Error! Your passwords did not match")';
        echo '</script>';
        exit ("");

    }
    include ("phptest.php");
    $result = mysql_query("SELECT id FROM users WHERE login='$login'",$db);
    $myrow = mysql_fetch_array($result);
    if (!empty($myrow['id'])) {
        echo '<meta http-equiv="refresh" content="3; URL=/register.php">';   
        echo '<script language="javascript">';
        echo 'alert("Error! This username is already taken, please choose another.")';
        echo '</script>';
        exit ("");


    }
    $res_e = mysql_query("SELECT * FROM users WHERE email='$email'",$db);

   if (mysql_num_rows($res_e) > 0) {

        echo '<meta http-equiv="refresh" content="3; URL=/register.php">';
        echo '<script language="javascript">';
        echo 'alert("Error! This mail is already registered. Please enter another mail.")';
        echo '</script>';
        exit ("");
    }

        mkdir("C:/Users/user/openserver/OSPanel/domains/melomania.web/userblog/"."$login"."_blog", 0700);
        //send pointer to link directory and user account
        $directorylink = ("/"."$login"."_blog");

    $result2 = mysql_query ("INSERT INTO users (login,firstname,lastname,email,password,directory) VALUES('$login','$fname','$lname','$email','$password','$directorylink')");
    if ($result2=='TRUE')
    {

      

        echo '<meta http-equiv="refresh" content="3; URL=/login.php">';   
        echo '<script language="javascript">';
        echo 'alert("Successful registration! Now, you can login into Melomania!")';
        echo '</script>';





    }
 else {


          echo '<meta http-equiv="refresh" content="3; URL=/index.php">';   
        echo '<script language="javascript">';
        echo 'alert("Something went wrong. Please check the project announcement or contact the support!")';
        echo '</script>';
    echo mysql_error();
    }
    ?>

  