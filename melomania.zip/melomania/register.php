<?php
    session_start();
    ?>

<?php
   
  if(isset($_SESSION['login'])){
      echo '<meta http-equiv="refresh" content="0; URL=/index.php">'; 
  }

    ?>



<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="shortcut icon" href="favicon-dark.png">

    <title>Melomania - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Styles and JS -->
     <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!--Scripts -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



     <!-- CSS -->
    <style type="text/css">


 .navbar-inverse {
 
  background-color: #000000;
 
  border-color: #551BFA;
 
}
.navbar-default .navbar-text {
 
  color: #551BFA;
 
}

.active{
background-color: #424949;


}

.nav-item {
margin:auto;
}

.form.inline{

	    margin-right: 20px;

}
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }

  .carousel {

  width: 100%;
  height:100%;
  align-content: center;

}

 .carousel-item{
   height:200px;
 }

  form:invalid input[type="submit"] {
    opacity: 0.25;
  }

}



</style>
     <!-- Icon -->

<link rel="shortcut icon" href="logo-final-dark-sized.png">

<script>

</script>


</head>


<body>





 <!-- Navigation panel -->
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="\index.php">Melomania</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  </button>
     <!-- Nav:home -->

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="\index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
     <!-- Nav:home -->

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dashboard</a>
     <!-- Nav:store/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-danger btn-sm btn-block" role="button" aria-disabled="true">Upload</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Notifications</a>
        </div>
      </li>

     <!-- Nav:playlist -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Melomania Center</a>
     <!-- Nav:playlist/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Promotion</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Trends</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-warning btn-sm btn-block" role="button" aria-disabled="true">FONFU+</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Special membership</a>
        </div>
     <!-- Nav:community -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Community</a> 
     <!-- Nav:community/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="/forum/" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Forum</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Bands</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Events</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">TOP 100</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">F.A.Q.</a>
        </div>

     <!-- Nav:myprofile -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">   
          <!-- PHP user getName() -->
          <?php

          if(empty($_SESSION['login'])) {

             echo "My profile";

          }
          
          else{

          echo "".$_SESSION['login']."";
          
          }

          ?>


        </a>  
</a>  

     <!-- Nav:myprofile/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My statistics</a>
          <div class="dropdown-divider"></div>
          <a href="/profile.php?login=123" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My profile</a>
        </div>
      </li>
    </ul>
     <!-- Nav:register or login -->
    <?php
    //show the user, if he in account/not
if (empty($_SESSION['login'])) {
 
      echo'<a href="\register.php" class="btn btn-primary mb-2 mr-sm-2" role="button" aria-disabled="true">Register</a>';
      echo'<a href="\login.php" class="btn btn-success mb-2 mr-sm-2" role="button" aria-disabled="true">Login</a>';
      
    }

    else {
       echo'<a href="\logout.php" class="btn btn-success" role="button" aria-disabled="true">Logout</a>';

    }
 ?>


    
  <?php
  //logout 
   if (isset($_POST['logout'])) {

          unset($_SESSION['username']); 

  echo '<meta http-equiv="refresh" content="1; URL=/index.php">';

  session_destroy(); 
    } 

    ?>
    </form>
  </div>
</nav>  

    <main role="main">
<div class="container">
    <form action="/registerprocess.php" class="form-horizontal" role="form" method="POST" onsubmit="return checkForm(this);" oninput='pwd2.setCustomValidity(pwd2.value != pwd.value ? "Passwords do not match." : "")'>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="text-center col-md-6">
                <p></p>
                <h3>Registration will take less than one minute and you will immediately find yourself in the Melomania!</h3>
                <hr>
            </div>
        </div>


        <div class="row">
            <div class="col-md-3 field-label-responsive">
                <label for="name">Your Username</label>  
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-user"></i></div>
                        <input type="login" name="login" class="form-control" id="name" placeholder="Try to creative!" required autofocus>
                    </div>
                </div>
            </div>

        </div>


    <div class="row">
            <div class="col-md-3 field-label-responsive">
                <label for="fname">Your first name</label>
            </div>
                <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
                        <input type="text" name="fname" class="form-control" id="fname" placeholder="John" required>
                    </div>
                </div>
            </div>
        </div>


            <div class="row">
            <div class="col-md-3 field-label-responsive">
                <label for="lname">Your last name</label>
            </div>
                <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
                        <input type="text" name="lname" class="form-control" id="lname" placeholder="Smith" required>
                    </div>
                </div>
            </div>
        </div>



        <div class="row">
            <div class="col-md-3 field-label-responsive">
                <label for="email">E-Mail Address</label>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-at"></i></div>
                        <input type="email" name="email" class="form-control" id="email" placeholder="your-email@example.com" required>
                    </div>
                </div>
            </div>
        </div>







        <div class="row">
            <div class="col-md-3 field-label-responsive">
            <label for="password">Password</label>
            </div>
            <div class="col-md-6">
                <div class="form-group has-danger">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem"><i class="fa fa-key"></i></div>
                        <input type="password" name="password" class="form-control" id="password" onkeyup='check()' placeholder="Password" required name=pwd1> 
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 field-label-responsive">
                <label for="passwordconfirm">Confirm Password</label>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                        <div class="input-group-addon" style="width: 2.6rem">
                            <i class="fa fa-repeat"></i>
                        </div>
                        <input type="password" name="passwordconfirm" class="form-control" onkeyup='check()' id="passwordconfirm" placeholder="Confirm password" name=pwd2>
                        

                    </div>
                </div>
            </div>
          </div>


        <div class="form-check">
  <input class="form-check-input" name=r type="checkbox" value="" id="defaultCheck1" required>
  <label class="form-check-label" for="defaultCheck1">I agree with a Melomania community</label>
  <a href="#" onclick='newwindowRULES()'>rules</a>
</div>
<p></p>
  <div class="form-check">
  <input class="form-check-input" name=r type="checkbox" value="" id="defaultCheck2" required>
  <label class="form-check-label" for="defaultCheck2">I agree with a FONFU license</label>
    <a href="#" onclick='newwindowFONFU()'>principles</a>
  </div>


<script>
//  opening in the new window
function newwindowRULES(){
  var newWin = window.open('/forum/viewtopic.php?id=2', 'example1', 'width=600,height=400');
};

function newwindowFONFU(){
  var newWin = window.open('/forum/321', 'example2', 'width=600,height=400');
};

</script>




        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 text-center">

                <button type="submit text-center" onclick="myFunction()" name=submit value="Show alert box" class="btn btn-success"><i class="fa fa-user-plus"></i>Finish!</button>

                </form>
                <p></p>
                <p><a href="\login.php">I already have a account.</a></p>

            </div>

        </div>

  
    </main>



      <!-- Copyright/footer -->

        <footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Melomania Developers
  </div>
  <!-- Copyright -->

</footer>




</body></html>