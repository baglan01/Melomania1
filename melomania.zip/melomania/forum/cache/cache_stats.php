<?php

if (!defined('FORUM_STATS_LOADED')) define('FORUM_STATS_LOADED', 1);

$forum_stats = array (
  'total_users' => '1',
  'last_user' => 
  array (
    'id' => '2',
    'username' => 'mrjohnny31',
  ),
  'total_topics' => '2',
  'total_posts' => '2',
  'cached' => 1589995239,
);

?>