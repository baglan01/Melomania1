<?php

$pun_colored_usergroups_cache = '.group_color_1 a:link, .group_color_1 { color: #12E3E1 !important; }
 .group_color_1 a:visited { color: #12E3E1; }
';
?>