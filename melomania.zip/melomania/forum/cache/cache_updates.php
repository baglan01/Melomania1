<?php

if (!defined('FORUM_UPDATES_LOADED')) define('FORUM_UPDATES_LOADED', 1);

$forum_updates = array (
  'cached' => 1577353427,
  'fail' => false,
);

?>