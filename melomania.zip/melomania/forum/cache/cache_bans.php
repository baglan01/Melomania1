<?php

define('FORUM_BANS_LOADED', 1);

$forum_bans = array (
);

?>