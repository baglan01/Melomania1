<?php

if (!defined('FORUM_EXT_VERSIONS_LOADED')) define('FORUM_EXT_VERSIONS_LOADED', 1);

$forum_ext_repos = array (
  'http://punbb.informer.com/extensions/1.4' => 
  array (
    'timestamp' => '1418978113',
    'extension_versions' => 
    array (
      'pun_colored_usergroups' => '1.2.4',
    ),
  ),
);

 $forum_ext_last_versions = array (
  'pun_colored_usergroups' => 
  array (
    'version' => '1.2.4',
    'repo_url' => 'http://punbb.informer.com/extensions/1.4',
  ),
);

$forum_ext_versions_update_cache = 1577365596;

?>