<?php

/** Connexion BDD */
const DB_DSN    = 'mysql:host=localhost;dbname=blog;charset=UTF8';
const DB_USER   = 'root';
const DB_PASS   = '';

/** Application Directory and URL */
const REP_BLOG      = 'C:/Users/user/openserver/OSPanel/domains/blogging.co/';
const URL_BLOG      = 'http://blogging.co/';
const REP_UPLOAD    = 'uploads/';