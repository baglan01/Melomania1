<?php
    $db = mysql_connect ("127.0.0.1", "melomania", "1234567890abcdE");
    mysql_select_db ("users",$db);
    ?>

