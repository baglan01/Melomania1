<?php
    session_start();
    ?>
<?php
include("phptest.php");
?>




<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>Melomania - share, comment, create!</title>
<link rel="shortcut icon" href="favicon-dark.png">

    <!-- Styles and JS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--Scripts -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

   
   <link rel="stylesheet" type="text/css" href="/src/style.css">


    <meta name="viewport" content="width=device-width, initial-scale=1.0">



  <style type="text/css">
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   color: white;
   text-align: center;
}


.anim-show{
	width:300px;
	background:#176387;
	color:#fff;
	font-size:25px;
	border:3px solid #2BA2DB;
	padding:20px;
	margin:auto;
	margin-bottom:20px;
	text-align:center;
	opacity:0; 
	transition: 1s; 
	animation: show 3s 1; 
       animation-fill-mode: forwards; 
       animation-delay: 1s; 
}

.centered-logo{
	margin:auto;


}

 .navbar-inverse {
 
  background-color: #000000;
 
  border-color: #551BFA;
 
}
.navbar-default .navbar-text {
 
  color: #551BFA;
 
}

.active{
background-color: #424949;


}

.nav-item {
    font-family:'Arial';

    margin:auto;
}

.form.inline{

	    margin-right: 20px;

}
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }

  .carousel {

  width: 100%;
  height:100%;
  align-content: center;

}

 .carousel-item{
   height:200px;
 }


section .section-title {
    text-align: center;
    color: #222;
    margin-bottom: 50px;
    text-transform: uppercase;
}
#footer {
    background: #222 !important;
}
#footer h5{
  padding-left: 10px;
    border-left: 3px solid #eeeeee;
    padding-bottom: 6px;
    margin-bottom: 20px;
    color:#080808;
}
#footer a {
    color: #ffffff;
    text-decoration: none !important;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
#footer ul.social li{
  padding: 3px 0;
}
#footer ul.social li a i {
    margin-right: 5px;
  font-size:25px;
  -webkit-transition: .5s all ease;
  -moz-transition: .5s all ease;
  transition: .5s all ease;
}
#footer ul.social li:hover a i {
  font-size:30px;
  margin-top:-10px;
}
#footer ul.social li a,
#footer ul.quick-links li a{
  color:#ffffff;
}
#footer ul.social li a:hover{
  color:#eeeeee;
}

@media (max-width:767px){
  #footer h5 {
    padding-left: 0;
    border-left: transparent;
    padding-bottom: 0px;
    margin-bottom: 10px;
}
}


@keyframes show{
 0%{ opacity:0; }
 100% { opacity:1; }
}
</style>
<script>
$(window).on("load",function() {
  $(window).scroll(function() {
    var windowBottom = $(this).scrollTop() + $(this).innerHeight();
    $(".column").each(function() {
      var objectBottom = $(this).offset().top + $(this).outerHeight();
            if (objectBottom < windowBottom) { 
        if ($(this).css("opacity")==0) {$(this).fadeTo(500,1);}
      } else { 
        if ($(this).css("opacity")==1) {$(this).fadeTo(500,0);}
      }
    });
  }).scroll();
});


//scrolling down 
$('a[href^="#"]').bind('click.smoothscroll',function (e) {
 e.preventDefault();
 
var target = this.hash,
 $target = $(target);
$('html, body').stop().animate({
 'scrollTop': $target.offset().top
 }, 500, 'swing', function () {
 window.location.hash = target;
 });
 });


</script>

</head>

     <!-- Navigation panel -->
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="\index.php">Melomania</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  </button>
     <!-- Nav:home -->

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="\index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
     <!-- Nav:home -->

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dashboard</a>
     <!-- Nav:store/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="/dashboard.php" class="btn btn-danger btn-sm btn-block" role="button" aria-disabled="true">Upload</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Notifications</a>
        </div>
      </li>

     <!-- Nav:playlist -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Melomania Center</a>
     <!-- Nav:playlist/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Promotion</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Trends</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-warning btn-sm btn-block" role="button" aria-disabled="true">FONFU+</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Special membership</a>
        </div>



     <!-- Nav:community -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Community</a> 
     <!-- Nav:community/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="/forum/" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Forum</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Bands</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Events</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">TOP 100</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">F.A.Q.</a>
        </div>

     <!-- Nav:myprofile -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">   
          <!-- PHP user getName() -->
          <?php

          if(empty($_SESSION['login'])) {

             echo "My profile";

          }
          
          else{

          echo "".$_SESSION['login']."";
          
          }

          ?>


        </a>  
</a>  

     <!-- Nav:myprofile/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My statistics</a>
          <div class="dropdown-divider"></div>
          <a href="/profile.php?login=
<?php
//admin check

$adminquery = mysql_query("SELECT adminaccesss FROM users WHERE login='$login'", $db);

          echo "".$_SESSION['login']."";


?>
         " class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My profile</a>





        </div>
      </li>
    </ul>
     <!-- Nav:register or login -->
    <?php
    //show the user, if he in account/not
if (empty($_SESSION['login'])) {
 
      echo'<a href="\register.php" class="btn btn-primary mb-2 mr-sm-2" role="button" aria-disabled="true">Register</a>';
      echo'<a href="\login.php" class="btn btn-success mb-2 mr-sm-2" role="button" aria-disabled="true">Login</a>';
      
    }

    else {
       echo'<a href="\logout.php" class="btn btn-success" role="button" aria-disabled="true">Logout</a>';

    }
 ?>


    
  <?php
  //logout 
   if (isset($_POST['logout'])) {

          unset($_SESSION['username']); 

  echo '<meta http-equiv="refresh" content="1; URL=/index.php">';

  session_destroy(); 
    } 

    ?>
    </form>
  </div>
</nav>	




<main>
<img class="centered-logo" width="520" height="422" src="logo-final.png" >


<div class="row-container">
<div class="row">
<div class="column-container">
<div class="column centered accent-purple">



<h2>Share, comment, create!</h2>
<p class="lead">
This your personal music blog from musicians. Our platform provides opportunities to share, create music and in need
to cooperate with other participants. Still don't believe it? We will answer you three questions, which we believe is given to everyone who visits our site.</p>

<div class="inline-elements centered tiny-gutters">
<a class="button" id="gotit" href="#scroll">Got it!</a>

</div>






</div>
</div>
</div>
</div>



<div class="row-container product-feature-river accent-blue" id="scroll">
<div class="row product-feature center-align-columns">
<div class="column-container">
<div class="column">
<h3><i>- What is the difference between Melomania and others similar projects?</i></h3>
<p>
We don’t want to brag, but all of your songs/melodies which you upload in Melomania is protected by a unique music patent license
FONFU (Free or not for use license). Which means that only with your permission
your song can be downloaded or used, well, or used for free if you are ready for distribution.</p>
<div class="inline-elements small-gutters">
<a class="button" href="#" target="_blank">More about F.O.N.F.U. license</a>
</div>
</div>
</div>
<div class="column-container column-7">
<div class="column">
<img class="" width="520" height="362" src="logo-final.png">
</div>
</div>
</div>
<div class="row product-feature center-align-columns">
<div class="column-container">
<div class="column">
<h3><i>- Should I switch from my current service to yours?</i></h3>
<p>We thought of everything to collaborate with other services like: SoundCloud, BandCamp, Youtube (GMAIL), Vimeo and other popular services. This means that in the future we present the ability to simultaneously download to all sites at the same time; But for now, you will be able to point sources to other services</p>
<div class="inline-elements small-gutters">

</div>
</div>
</div>
<div class="column-container">
<div class="column">
<img class="" width="520" height="422" src="logo-final.png">
</div>
</div>
</div>
</div>
<div class="row-container product-feature-river accent-blue">
<div class="row product-feature center-align-columns">
<div class="column-container">
<div class="column">
<h3><i>- But what if I have a music band or I am a promoter?</i></h3>
<p>Everything is provided, if you are a music group, then you get exactly 1 account and you can leave opinions and write from a specific user. If you are a promoter, we would advise you our <strong>"STAFF membership"</strong> which will help you to track the right artists in different genres.</p>
<div class="inline-elements small-gutters">
<a class="button" href="#" target="_blank">More about STAFF membership</a>
</div>
</div>
</div>
<div class="column-container column-7">
<div class="column perspective-right">
<img class="" width="520" height="422" src="logo-final.png">






</div>
</div>

</div>

</div>

<div class="row-container">
<div class="row">
<div class="column-container">
<div class="column centered accent-green">





<h2>And so finally, after all that was, why don't you even try (and we remind you that everything is <strong>absolutely*</strong> free)?</h2>
<p class="lead">But, if you have more questions, please check out our F.A.Q. </p>
<p class="lead">*Except special memberships, but they're are not required to bought.</p>

<div class="inline-elements centered tiny-gutters">
<a class="button" href="\choose.html" target="_blank">OK! Let's register!</a>

</div>




</div>




<div class="column centered accent-gray">
<a class="button" href="/faq.php" target="_blank">I have a more questions</a>
</div>
</div>
</div>
</div>




 </maissn>

  <section id="footer">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
          <ul class="list-unstyled list-inline social text-center">
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
          </ul>
        </div>
      </div>  
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
          <p><u><a href="/index.php">Melomania</a></u> is a registered trade mark</p>
          <p class="h6"><a class="text-green ml-2" href="/devblog.php" target="_blank">© Melomania Developers</a></p>
          <p class="h6"><a class="text-green ml-2" href="#">v.1.0.0</a></p>

        </div>
      </div>  
    </div>

  </section>



 </body>

</html>