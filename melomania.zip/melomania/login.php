<?php
    session_start();
    ?>

<?php
   
  if(isset($_SESSION['login'])){

      echo '<meta http-equiv="refresh" content="0; URL=/index.php">'; 

  }

    ?>



<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Melomania - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Styles and JS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!--Scripts -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>





     <!-- CSS -->
    <style type="text/css">

.col-md-8 {

    margin: center;

}

 .navbar-inverse {
 
  background-color: #000000;
 
  border-color: #551BFA;
 
}
.navbar-default .navbar-text {
 
  color: #551BFA;
 
}

.active{
background-color: #424949;


}

.nav-item {
    margin-right: 20px;
}

.form.inline{

      margin-right: 20px;

}
  .carousel-inner img {
    width: 100%;
    height: 100%;
  }

  .carousel {

  width: 100%;
  height:100%;
  align-content: center;

}

 .carousel-item{
   height:200px;
 }


}



</style>
     <!-- Icon -->

<link rel="shortcut icon" href="logo-final-dark-sized.png">

</head>


<body>
     <!-- Navigation panel -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="\index.php">Melomania</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  </button>
     <!-- Nav:home -->

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="\index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
     <!-- Nav:home -->

        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dashboard</a>
     <!-- Nav:store/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-danger btn-sm btn-block" role="button" aria-disabled="true">Upload</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Notifications</a>
        </div>
      </li>

     <!-- Nav:playlist -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Melomania Center</a>
     <!-- Nav:playlist/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Promotion</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Trends</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-warning btn-sm btn-block" role="button" aria-disabled="true">FONFU+</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Special membership</a>
        </div>



     <!-- Nav:community -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Community</a> 
     <!-- Nav:community/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="/forum/" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Forum</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Bands</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">Events</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">TOP 100</a>
          <div class="dropdown-divider"></div>
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">F.A.Q.</a>
        </div>

     <!-- Nav:myprofile -->

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">   
          <!-- PHP user getName() -->
          <?php

          if(empty($_SESSION['login'])) {

             echo "My profile";

          }
          
          else{

          echo "".$_SESSION['login']."";
          
          }

          ?>


        </a>  
</a>  

     <!-- Nav:myprofile/list -->

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="#" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My statistics</a>
          <div class="dropdown-divider"></div>
          <a href="/profile.php?login=123" class="btn btn-info btn-sm btn-block" role="button" aria-disabled="true">My profile</a>
        </div>
      </li>
    </ul>
     <!-- Nav:register or login -->
    <?php
    //show the user, if he in account/not
if (empty($_SESSION['login'])) {
 
      echo'<a href="\register.php" class="btn btn-primary mb-2 mr-sm-2" role="button" aria-disabled="true">Register</a>';
      echo'<a href="\login.php" class="btn btn-success mb-2 mr-sm-2" role="button" aria-disabled="true">Login</a>';
      
    }

    else {
       echo'<a href="\logout.php" class="btn btn-success" role="button" aria-disabled="true">Logout</a>';

    }
 ?>


    
  <?php
  //logout 
   if (isset($_POST['logout'])) {

          unset($_SESSION['username']); 

  echo '<meta http-equiv="refresh" content="1; URL=/index.php">';

  session_destroy(); 
    } 

    ?>
    </form>
  </div>
</nav>  


<main class="login-form">
    <div class="cotainer">
         <div class="row">
            <div class="col-md-3"></div>
            <div class="text-center col-md-6">
                <p></p>
                <h3>Login and password are enough for authorization. Convenient and easy, isn't it?</h3>
                <hr>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="testreg.php" class="form-horizontal" role="form" method="POST">

                   
                            <div class="form-group row">
                                <label for="email_address" class="col-md-4 col-form-label text-md-right">Username</label>
                                <div class="col-md-6">
                                    <input name ="login" type="text" id="email_address" class="form-control" name="email-address" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                <div class="col-md-6">
                                    <input name="password" type="password" id="password" class="form-control" name="password" required>
                                    
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember"> Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">Auth</button>
    
                              </form>
                              </div>
                                            <p></p>
                            <div class="cold-md-6 offset-md-4">
                                <a href="#" class="btn btn-link">
                                    Can't login?
                                </a>
                            </div>
                    </div>
                   
             
            </div>
        </div>
    </div>
    </div>

</main>



      <!-- Copyright/footer -->

        <footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Melomania Developers
  </div>
  <!-- Copyright -->

</footer>



</body></html>